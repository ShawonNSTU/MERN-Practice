package com.example.micronautcrud.controller

import com.example.micronautcrud.domain.Book
import com.example.micronautcrud.repository.BookRepository
import io.micronaut.http.HttpResponse
import io.micronaut.http.annotation.*
import io.micronaut.http.exceptions.HttpStatusException

@Controller("/books")
class BookController(private val bookRepository: BookRepository) {

    @Get("/")
    fun getAllBooks(): Iterable<Book> {
        return bookRepository.findAll()
    }

    @Get("/{id}")
    fun getBookById(id: Long): Book {
        return bookRepository.findById(id).orElseThrow { Exception("Book not found") }
    }

    @Post("/")
    fun saveBook(@Body book: Book): Book {
        return bookRepository.save(book)
    }

    @Put("/{id}")
    fun updateBook(id: Long, @Body book: Book): Book {
        if (bookRepository.existsById(id)) {
            return bookRepository.update(book)
        }
        throw Exception("Book not found")
    }

    @Delete("/{id}")
    fun deleteBook(id: Long): HttpResponse<Any> {
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id)
            return HttpResponse.noContent()
        }
        throw Exception("Book not found")
    }
}
