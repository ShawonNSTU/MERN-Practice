package com.example.micronautcrud.repository

import com.example.micronautcrud.domain.Book
import io.micronaut.data.annotation.Repository
import io.micronaut.data.repository.CrudRepository

@Repository
interface BookRepository : CrudRepository<Book, Long> {
    
}
